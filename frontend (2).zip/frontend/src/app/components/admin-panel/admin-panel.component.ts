import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HotelService } from '../../services/hotel.service';
import { ReviewService } from '../../services/review.service';
import { BookingService } from '../../services/booking.service';
import { AuthService } from '../../core/services/auth.service';
import { AnalyticsStatsComponent } from './analytics-stats/analytics-stats.component';
import { HotelFormManagerComponent } from './hotel-form-manager/hotel-form-manager.component';
import { RoomFormManagerComponent } from './room-form-manager/room-form-manager.component';
import { ReviewModeratorComponent } from './review-moderator/review-moderator.component';

@Component({
  selector: 'app-admin-panel',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    AnalyticsStatsComponent, 
    HotelFormManagerComponent, 
    RoomFormManagerComponent, 
    ReviewModeratorComponent
  ],
  templateUrl: './admin-panel.component.html',
  styleUrl: './admin-panel.component.css'
})
export class AdminPanelComponent implements OnInit {
  hotelService = inject(HotelService);
  reviewService = inject(ReviewService);
  bookingService = inject(BookingService);
  auth = inject(AuthService);

  activeTab = signal<'hotels' | 'reviews' | 'bookings'>('hotels');
  
  // Create Hotel Form
  isSubmittingHotel = signal(false);
  hotelForm = {
    name: '',
    location: '',
    description: '',
    amenities: 'WiFi, Pool, Gym, Spa, Parking'
  };

  // Create Room Form
  isSubmittingRoom = signal(false);
  roomForm = {
    hotelId: 0,
    roomType: 'Double Room',
    pricePerNight: 5000,
    amenities: 'AC, Flat-screen TV, Balcony, Mini Fridge'
  };

  // Reviews responding
  selectedHotelIdForReviews = 0;
  reviewResponses: { [key: number]: string } = {};

  ngOnInit() {
    if (this.auth.isAdmin()) {
      this.hotelService.getAllHotels().subscribe();
      this.bookingService.getAllBookings().subscribe();
    } else if (this.auth.isManager()) {
      this.hotelService.getMyHotels().subscribe();
      this.bookingService.getAllBookings().subscribe();
    }
  }

  submitHotel() {
    this.isSubmittingHotel.set(true);
    this.hotelService.createHotel(this.hotelForm).subscribe({
      next: () => {
        this.isSubmittingHotel.set(false);
        this.hotelForm = {
          name: '',
          location: '',
          description: '',
          amenities: 'WiFi, Pool, Gym, Spa, Parking'
        };
        if (this.auth.isAdmin()) {
          this.hotelService.getAllHotels().subscribe();
        } else {
          this.hotelService.getMyHotels().subscribe();
        }
      },
      error: () => this.isSubmittingHotel.set(false)
    });
  }

  submitRoom() {
    if (this.roomForm.hotelId === 0) {
      alert('Please select a hotel first');
      return;
    }

    this.isSubmittingRoom.set(true);
    this.hotelService.createRoom(this.roomForm).subscribe({
      next: () => {
        this.isSubmittingRoom.set(false);
        this.roomForm = {
          hotelId: this.roomForm.hotelId,
          roomType: 'Double Room',
          pricePerNight: 5000,
          amenities: 'AC, Flat-screen TV, Balcony, Mini Fridge'
        };
      },
      error: () => this.isSubmittingRoom.set(false)
    });
  }

  loadReviewsForHotel() {
    if (this.selectedHotelIdForReviews > 0) {
      this.reviewService.getHotelReviews(this.selectedHotelIdForReviews).subscribe();
    }
  }

  submitResponse(reviewId: number) {
    const text = this.reviewResponses[reviewId];
    if (!text || text.trim().length === 0) return;

    this.reviewService.respondToReview(reviewId, text, this.selectedHotelIdForReviews).subscribe({
      next: () => {
        delete this.reviewResponses[reviewId];
      }
    });
  }

  getBookingStatusClass(status: string): string {
    if (status === 'Confirmed' || status === 'Completed' || status === 'Paid') return 'badge-success';
    if (status === 'Pending') return 'badge-warning';
    return 'badge-danger';
  }
}
