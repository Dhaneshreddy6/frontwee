import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule, Router } from '@angular/router';
import { HotelService } from '../../services/hotel.service';
import { ReviewService } from '../../services/review.service';
import { BookingService } from '../../services/booking.service';
import { AuthService } from '../../core/services/auth.service';
import { RoomCardComponent } from './room-card/room-card.component';
import { ReviewCardComponent } from './review-card/review-card.component';
import { BookingFormDialogComponent } from './booking-form-dialog/booking-form-dialog.component';

@Component({
  selector: 'app-hotel-detail',
  standalone: true,
  imports: [
    CommonModule, 
    FormsModule, 
    RouterModule, 
    RoomCardComponent, 
    ReviewCardComponent, 
    BookingFormDialogComponent
  ],
  templateUrl: './hotel-detail.component.html',
  styleUrl: './hotel-detail.component.css'
})
export class HotelDetailComponent implements OnInit {
  hotelService = inject(HotelService);
  reviewService = inject(ReviewService);
  bookingService = inject(BookingService);
  auth = inject(AuthService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  hotelId = 0;
  minDate = '';
  minCheckOutDate = '';
  
  dates = {
    checkIn: '',
    checkOut: ''
  };

  // Reservation dialog
  activeBookingRoom = signal<any | null>(null);
  isReserving = signal(false);
  bookingForm = {
    guestName: '',
    guestEmail: '',
    guestPhone: '',
    numberOfGuests: 1,
    specialRequests: ''
  };

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.hotelId = parseInt(params['id'], 10);
      if (this.hotelId) {
        this.loadHotelDetails();
      }
    });

    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
    
    const tomorrow = new Date(today);
    tomorrow.setDate(today.getDate() + 1);
    this.minCheckOutDate = tomorrow.toISOString().split('T')[0];

    this.dates.checkIn = this.minDate;
    this.dates.checkOut = this.minCheckOutDate;
  }

  loadHotelDetails() {
    this.hotelService.getHotelById(this.hotelId).subscribe();
    this.hotelService.getRoomsByHotel(this.hotelId).subscribe();
    this.reviewService.getHotelReviews(this.hotelId).subscribe();
    this.reviewService.getHotelSummary(this.hotelId).subscribe();
  }

  onDateChange() {
    if (this.dates.checkIn) {
      const checkInDate = new Date(this.dates.checkIn);
      const nextDay = new Date(checkInDate);
      nextDay.setDate(checkInDate.getDate() + 1);
      this.minCheckOutDate = nextDay.toISOString().split('T')[0];

      if (this.dates.checkOut <= this.dates.checkIn) {
        this.dates.checkOut = this.minCheckOutDate;
      }
    }
  }

  onSearchRooms() {
    this.hotelService.getAvailableRooms(
      this.hotelId, 
      this.dates.checkIn, 
      this.dates.checkOut
    ).subscribe();
  }

  getNightsCount(): number {
    if (!this.dates.checkIn || !this.dates.checkOut) return 1;
    const start = new Date(this.dates.checkIn);
    const end = new Date(this.dates.checkOut);
    const diff = end.getTime() - start.getTime();
    const nights = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return nights <= 0 ? 1 : nights;
  }

  bookRoom(room: any) {
    if (!this.auth.isLoggedIn()) {
      this.router.navigate(['/auth']);
      return;
    }

    this.activeBookingRoom.set(room);
    this.bookingForm = {
      guestName: this.auth.currentUser()?.name || '',
      guestEmail: this.auth.currentUser()?.email || '',
      guestPhone: '',
      numberOfGuests: 1,
      specialRequests: ''
    };
  }

  submitReservation() {
    const room = this.activeBookingRoom();
    if (!room) return;

    this.isReserving.set(true);
    const payload = {
      roomId: room.roomId,
      hotelId: this.hotelId,
      checkInDate: new Date(this.dates.checkIn).toISOString(),
      checkOutDate: new Date(this.dates.checkOut).toISOString(),
      numberOfGuests: this.bookingForm.numberOfGuests,
      specialRequests: this.bookingForm.specialRequests,
      guestName: this.bookingForm.guestName,
      guestEmail: this.bookingForm.guestEmail,
      guestPhone: this.bookingForm.guestPhone
    };

    this.bookingService.createBooking(payload).subscribe({
      next: () => {
        this.isReserving.set(false);
        this.activeBookingRoom.set(null);
        this.router.navigate(['/dashboard']);
      },
      error: () => this.isReserving.set(false)
    });
  }

  markHelpful(reviewId: number) {
    this.reviewService.markHelpful(reviewId, this.hotelId).subscribe();
  }

  getHotelGradient(id: number): string {
    const gradients = [
      'linear-gradient(135deg, #4338ca 0%, #1e1b4b 100%)',
      'linear-gradient(135deg, #6d28d9 0%, #311042 100%)',
      'linear-gradient(135deg, #0f766e 0%, #042f2e 100%)',
      'linear-gradient(135deg, #b91c1c 0%, #450a0a 100%)',
      'linear-gradient(135deg, #1d4ed8 0%, #172554 100%)'
    ];
    return gradients[id % gradients.length];
  }

 // hotel-detail.component.ts
// hotel-detail.component.ts
// hotel-detail.component.ts

getAmenities(amenities: any[] | string | null): string[] {
  console.log('getAmenities called with:', amenities);

  if (!amenities) {
    return ['WiFi', 'AC', 'TV']; // fallback
  }

  // 1. Handle array of objects from Swagger response
  if (Array.isArray(amenities)) {
    return amenities.map(a => {
      if (typeof a === 'object' && a !== null) {
        return a.name; // 👈 Extracts "Laundry", "Airport Shuttle", etc.
      }
      return String(a);
    });
  }

  // 2. Handle string fallback
  if (typeof amenities === 'string') {
    return amenities.split(',')
      .map(s => s.trim())
      .filter(s => s.length > 0);
  }

  return [];
}

  getStarRows() {
    const summary = this.reviewService.summaries();
    if (!summary) return [];

    const total = summary.totalReviews || 1;
    return [
      { stars: 5, count: summary.fiveStarCount, percent: (summary.fiveStarCount / total) * 100 },
      { stars: 4, count: summary.fourStarCount, percent: (summary.fourStarCount / total) * 100 },
      { stars: 3, count: summary.threeStarCount, percent: (summary.threeStarCount / total) * 100 },
      { stars: 2, count: summary.twoStarCount, percent: (summary.twoStarCount / total) * 100 },
      { stars: 1, count: summary.oneStarCount, percent: (summary.oneStarCount / total) * 100 }
    ];
  }
}
